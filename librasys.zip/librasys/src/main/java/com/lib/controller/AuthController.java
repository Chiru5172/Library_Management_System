package com.lib.controller;

import com.lib.entity.Member;
import com.lib.repo.MemberRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private MemberRepo memberRepo;

    @PostMapping("/login")
    public Member login(@RequestBody Member loginRequest) {
        Optional<Member> member = memberRepo.findByEmail(loginRequest.getEmail());

        if (member.isPresent() && member.get().getPassword().equals(loginRequest.getPassword())) {
            return member.get();
        } else {
            throw new RuntimeException("Invalid email or password");
        }
    }
}
