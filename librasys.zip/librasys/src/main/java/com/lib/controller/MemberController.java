package com.lib.controller;

import com.lib.entity.Member;
import com.lib.repo.MemberRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:3000") // Allow frontend access
@RestController
@RequestMapping("/api/member")
public class MemberController {

    @Autowired
    private MemberRepo memberRepo;

    // ✅ 1. Register a New Member
    @PostMapping
    public ResponseEntity<Member> registerMember(@RequestBody Member member) {
        if (memberRepo.findByEmail(member.getEmail()).isPresent()) {
            return ResponseEntity.badRequest().build(); // If email exists, return error
        }
        Member savedMember = memberRepo.save(member);
        return ResponseEntity.ok(savedMember);
    }

    // ✅ 2. Get All Members
    @GetMapping
    public List<Member> getAllMembers() {
        return memberRepo.findAll();
    }

    // ✅ 3. Get Member by ID
    @GetMapping("/{id}")
    public ResponseEntity<Member> getMemberById(@PathVariable Long id) {
        Optional<Member> member = memberRepo.findById(id);
        return member.map(ResponseEntity::ok)
                     .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // ✅ 4. Update Member Details
    @PutMapping("/{id}")
    public ResponseEntity<Member> updateMember(@PathVariable Long id, @RequestBody Member updatedMember) {
        return memberRepo.findById(id)
                .map(member -> {
                    member.setName(updatedMember.getName());
                    member.setEmail(updatedMember.getEmail());
                    member.setPassword(updatedMember.getPassword()); // Hash this in real-world apps
                    member.setRole(updatedMember.getRole());
                    return ResponseEntity.ok(memberRepo.save(member));
                }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // ✅ 5. Delete a Member
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMember(@PathVariable Long id) {
        if (memberRepo.existsById(id)) {
            memberRepo.deleteById(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
