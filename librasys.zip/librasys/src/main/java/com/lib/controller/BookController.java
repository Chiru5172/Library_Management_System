package com.lib.controller;

import com.lib.entity.Book;
import com.lib.repo.BookRepo;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/book")
@CrossOrigin(origins = "http://localhost:3000")
public class BookController {
    private final BookRepo bookRepo;

    public BookController(BookRepo bookRepo) {
        this.bookRepo = bookRepo;
    }

    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        return ResponseEntity.ok(bookRepo.findAll());
    }

    @GetMapping("/available")
    public ResponseEntity<List<Book>> getAvailableBooks() {
        return ResponseEntity.ok(bookRepo.findByAvailableTrue());
    }

    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        book.setAvailable(true); 
        return ResponseEntity.ok(bookRepo.save(book));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> editBook(@PathVariable Long id, @RequestBody Book updatedBook) {
        Optional<Book> existingBookOpt = bookRepo.findById(id);

        if (existingBookOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Book not found");
        }

        Book existingBook = existingBookOpt.get();
        existingBook.setTitle(updatedBook.getTitle());
        existingBook.setAuthor(updatedBook.getAuthor());
        existingBook.setGenre(updatedBook.getGenre());
        existingBook.setIsbn(updatedBook.getIsbn());
        existingBook.setAvailable(updatedBook.isAvailable());

        return ResponseEntity.ok(bookRepo.save(existingBook));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable Long id) {
        if (!bookRepo.existsById(id)) {
            return ResponseEntity.badRequest().body("Book not found");
        }
        
        bookRepo.deleteById(id);
        return ResponseEntity.ok("Book deleted successfully");
    }
}
