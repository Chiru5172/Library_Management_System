package com.lib.controller;

import com.lib.entity.Borrowing;
import com.lib.entity.Book;
import com.lib.entity.Member;
import com.lib.repo.BorrowingRepo;
import com.lib.repo.BookRepo;
import com.lib.repo.MemberRepo;
import com.lib.service.BorrowingService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/borrowing")
@CrossOrigin(origins = "http://localhost:3000")
public class BorrowingController {

    @Autowired
    private BorrowingService borrowingService;
    
    @Autowired
    private BorrowingRepo borrowingRepo;

    @Autowired
    private BookRepo bookRepo;

    @Autowired
    private MemberRepo memberRepo;

    // ✅ Get All Borrowed Books
    @GetMapping
    public List<Borrowing> getAllBorrowings() {
        return borrowingService.getAllBorrowings();
    }

    // ✅ Get Borrowed Books by Member ID
    @GetMapping("/member/{memberId}")
    public ResponseEntity<List<Borrowing>> getBorrowedBooks(@PathVariable Long memberId) {
        List<Borrowing> borrowedBooks = borrowingRepo.findByMemberIdAndReturnedFalse(memberId);
        return ResponseEntity.ok(borrowedBooks);
    }

    // ✅ Borrow a Book
    @PostMapping("/borrow")
    public ResponseEntity<String> borrowBook(@RequestParam Long memberId, @RequestParam Long bookId) {
        Optional<Member> memberOpt = memberRepo.findById(memberId);
        Optional<Book> bookOpt = bookRepo.findById(bookId);

        if (memberOpt.isEmpty() || bookOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Invalid Member or Book ID");
        }

        Book book = bookOpt.get();
        if (!book.isAvailable()) {
            return ResponseEntity.badRequest().body("Book is not available for borrowing");
        }

        if (borrowingRepo.existsByMemberIdAndBookIdAndReturnedFalse(memberId, bookId)) {
            return ResponseEntity.badRequest().body("You have already borrowed this book!");
        }

        book.setAvailable(false);
        bookRepo.save(book);

        Borrowing borrowing = new Borrowing();
        borrowing.setMember(memberOpt.get());
        borrowing.setBook(book);
        borrowing.setBorrowDate(LocalDate.now());
        borrowing.setDueDate(LocalDate.now().plusDays(14)); // 14 days due date
        borrowing.setReturned(false);
        borrowingRepo.save(borrowing);

        return ResponseEntity.ok("Book borrowed successfully");
    }

    // ✅ Return a Book
    @PutMapping("/{id}/return")
    public ResponseEntity<String> returnBook(@PathVariable Long id) {
        Optional<Borrowing> borrowingOpt = borrowingRepo.findById(id);

        if (borrowingOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Borrowing record not found");
        }

        Borrowing borrowing = borrowingOpt.get();
        if (borrowing.isReturned()) {
            return ResponseEntity.badRequest().body("Book already returned");
        }

        borrowing.setReturned(true);
        borrowingRepo.save(borrowing);

        Book book = borrowing.getBook();
        book.setAvailable(true);
        bookRepo.save(book);

        return ResponseEntity.ok("Book returned successfully");
    }
}
