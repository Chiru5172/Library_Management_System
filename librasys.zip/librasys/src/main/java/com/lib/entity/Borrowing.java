package com.lib.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Borrowing {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    private Member member;
    @ManyToOne
    private Book book;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private boolean returned = false;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Member getMember() {
		return member;
	}
	public void setMember(Member member) {
		this.member = member;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public LocalDate getBorrowDate() {
		return borrowDate;
	}
	public void setBorrowDate(LocalDate borrowDate) {
		this.borrowDate = borrowDate;
	}
	public LocalDate getDueDate() {
		return dueDate;
	}
	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}
	public boolean isReturned() {
		return returned;
	}
	public void setReturned(boolean returned) {
		this.returned = returned;
	}
	@Override
	public String toString() {
		return "Borrowing [id=" + id + ", member=" + member + ", book=" + book + ", borrowDate=" + borrowDate
				+ ", dueDate=" + dueDate + ", returned=" + returned + "]";
	}
	public Borrowing(Long id, Member member, Book book, LocalDate borrowDate, LocalDate dueDate, boolean returned) {
		super();
		this.id = id;
		this.member = member;
		this.book = book;
		this.borrowDate = borrowDate;
		this.dueDate = dueDate;
		this.returned = returned;
	}
	public Borrowing() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}

