package com.lib.service;

import com.lib.entity.Member;
import com.lib.repo.MemberRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MemberService {

    @Autowired
    private MemberRepo memberRepo;

    public List<Member> getAllMembers() {
        return memberRepo.findAll();
    }

    public String deleteMember(Long memberId) {
        if (memberRepo.existsById(memberId)) {
            memberRepo.deleteById(memberId);
            return "Member deleted successfully!";
        }
        return "Member not found!";
    }
}
