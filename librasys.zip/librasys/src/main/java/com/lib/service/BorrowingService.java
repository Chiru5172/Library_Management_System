package com.lib.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lib.entity.Borrowing;
import com.lib.repo.BorrowingRepo;

@Service
public class BorrowingService {
    @Autowired
    private BorrowingRepo borrowingRepo;

    public List<Borrowing> getAllBorrowings() {
        return borrowingRepo.findAll();
    }

    public Borrowing borrowBook(Borrowing borrowing) {
        return borrowingRepo.save(borrowing);
    }

    public Borrowing getBorrowingById(Long id) {
        return borrowingRepo.findById(id).orElse(null);
    }

    public void returnBook(Long id) {
        borrowingRepo.deleteById(id);
    }
}
