package com.lib.repo;

import com.lib.entity.Borrowing;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BorrowingRepo extends JpaRepository<Borrowing, Long> {
    List<Borrowing> findByMemberIdAndReturnedFalse(Long memberId);
    boolean existsByMemberIdAndBookIdAndReturnedFalse(Long memberId, Long bookId);
}
